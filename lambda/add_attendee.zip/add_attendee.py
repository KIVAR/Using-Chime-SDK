import boto3
import json

def lambda_handler(event, context):
    """
    Adds an attendee to a Chime meeting
    :return:
    """
    session = boto3.Session()
    chime = session.client('chime')
    ddb = boto3.resource('dynamodb')

    attendee_meeting_name = event['attendee_meeting_name']
    attendee_name = event['attendee_name']

    # Retrieve meeting name from DynamoDB
    table = ddb.Table("chime-meetings")

    response = table.get_item(
        Key={
            'meeting_name': attendee_meeting_name,
        }
    )
  
    if 'Item' not in response:
        return f'Meeting {attendee_meeting_name} does not exist!', 503

    meeting = response['Item']['meeting']
    meeting_id = response['Item']['meeting_id']

    try:
        response = chime.create_attendee(
            MeetingId=meeting_id,
            ExternalUserId=attendee_name,
            Tags=[
                {
                    'Key': 'Attendee for meeting',
                    'Value': attendee_name
                },
            ]
        )
    except Exception as err:
        return json.dumps(str(err)), 503

    result = {}
    result['meeting'] = meeting
    result['attendee'] = {'Attendee': response['Attendee']}

    return json.dumps(result), 201